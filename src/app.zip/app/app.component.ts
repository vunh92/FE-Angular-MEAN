import { Component } from '@angular/core';

@Component({
  selector: 'app-root', // tên
  templateUrl: './app.component.html', // html
  styleUrls: ['./app.component.css'] // css
})
export class AppComponent {
  title = 'Hello Angular';

  getData(data:any){
    //console.log(data);
  }
}
