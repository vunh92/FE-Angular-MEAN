import { Injectable } from '@angular/core';

// Gọi HttpClient, HttpHeaders
import { HttpClient, HttpHeaders } from '@angular/common/http';

// Gọi observable
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(private http: HttpClient) { }

  url = 'http://localhost:3000/api/';

  // cấu hình header
  option = { headers: new HttpHeaders().set("Content-Type", "application/x-www-form-urlencoded") };

  list_product()
  {
    return this.http.get( this.url + 'product/list' );
  }

  list_aside()
  {
    return this.http.get( this.url + 'category/aside' );
  }

  get_id_category(slug:any)
  {
    return this.http.get( this.url + 'category/getid/' + slug );
  }

  list_product_from_parent(parent:any)
  {
    return this.http.get( this.url + 'product/listProduct/' + parent );
  }

  get_info_product(slug:any)
  {
    return this.http.get( this.url + 'product/info/' + slug );
  }

  related__products(id_product:any, id_category:any)
  {
    return this.http.get( this.url + 'product/related__products/' + id_product + '/' + id_category );
  }

  send_data_contact(data:any)
  {
    let body = new URLSearchParams();

    body.set('name', data.name);
    body.set('email', data.email);
    body.set('phone', data.phone);
    body.set('address', data.address);

    return this.http.post(this.url + 'contact/add', body, this.option);
  }

  send_data_login(data:any)
  {
    let body = new URLSearchParams();

    body.set('username', data.username);
    body.set('password', data.password);

    return this.http.post(this.url + 'user/login', body, this.option);
  }

  get_data_category<T>(): Observable<T>
  {
    return this.http.get( this.url + 'product/info/' ).pipe(map((data:any) => data));
  }
}
