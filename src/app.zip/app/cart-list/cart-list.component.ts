import { Component, OnInit } from '@angular/core';

import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

// Gọi actions và models
import { Cart } from '../Models/cart';
import { updateCart, deleteCart } from '../Store/Actions/cart.action';

@Component({
  selector: 'app-cart-list',
  templateUrl: './cart-list.component.html',
  styleUrls: ['./cart-list.component.css']
})
export class CartListComponent implements OnInit {

  currentValue: Number = 0;
  cart$: Observable<[]>;

  constructor(private store: Store<{ cart: [] }>) {
    this.cart$ = store.select('cart');
  }

  get_cart(){
    return this.cart$.pipe(map((data:any) => data));
  }

  array=[{
    id: 0,
    name: '',
    price: 0,
    qty: 0
  }];

  update={ id: '', name: '', qty: 0, price: 0 }

  ngOnInit(): void {
    this.get_cart()
    .subscribe((kq:any)=>{
      this.array = kq;
    });
  }

  data_update(id:any, name:any, qty:any, price:any){
    this.update = { id, name, qty, price };
  }

  update_cart(id:any, name:any, qty:any, price:any){
    this.store.dispatch(updateCart(new Cart(id.value, name.value, parseInt(price.value),parseInt(qty.value))))
  }

  deleteCart(id:any){
    this.store.dispatch(deleteCart(id))
  }

}
