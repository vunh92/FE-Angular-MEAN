import { Component, OnInit } from '@angular/core';

// Gọi ActivatedRoute, ParamMap
import { ActivatedRoute, ParamMap } from '@angular/router';

// Gọi Service
import { AppService } from '../app.service';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {

  constructor(private router: ActivatedRoute, private service: AppService) { }

  slug:any;
  id_category:any;
  list_product:any;

  // phân trang
  pageSize = 3;
  p = 1;
  total:any;

  ngOnInit(): void {
    this.router
    .paramMap
    .subscribe((params:ParamMap)=>{
      this.slug = params.get('id')

      this.service
      .get_id_category(this.slug)
      .subscribe((kq:any)=>{
        this.id_category = kq['data'];

        this.service
        .list_product_from_parent(this.id_category)
        .subscribe((kq2: any)=>{
          this.list_product = kq2['data'];

          this.total = this.list_product.length;
        })
      })
    });
  }

}
