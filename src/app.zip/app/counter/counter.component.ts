import { Component, OnInit } from '@angular/core';

// Gọi Store
import { Store } from '@ngrx/store';
import { increment, decrement, reset } from '../counter.actions';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-counter',
  templateUrl: './counter.component.html',
  styleUrls: ['./counter.component.css']
})
export class CounterComponent implements OnInit {

  count: Observable<number>;

  constructor(private store: Store<{count: number}>) {
    this.count = store.select('count')
  }

  ngOnInit(): void {
  }

  _increment(){
    this.store.dispatch(increment())
  }

  _decrement(){
    this.store.dispatch(decrement())
  }

  _reset(){
    this.store.dispatch(reset())
  }

}
