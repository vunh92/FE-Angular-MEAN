import { Component, OnInit, Input } from '@angular/core';

import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  @Input() _title:any;

  cart$: Observable<[]>;

  currentValue: Number = 0;

  constructor(private store: Store<{ cart: [] }>) {
    this.cart$ = store.select('cart');
  }

  get_cart(){
    return this.cart$.pipe(map((data:any) => data));
  }

  ngOnInit(): void {
    //console.log(this._title);
    this.get_cart()
    .subscribe((kq:any)=>{
      this.currentValue = kq.length;
    });
  }

  search(t:any){
    alert(t.value);
  }

}
