import { Component, OnInit } from '@angular/core';

// Gọi service
import { AppService } from '../app.service';

import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { Info } from '../Models/info';
import { addInfo, updateInfo, deleteInfo } from '../Store/Actions/info.action';

// Gọi actions và models
import { Cart } from '../Models/cart';
import { addCart } from '../Store/Actions/cart.action';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  infos: Info[] = [];
  //info$: Observable<[]>;
  currentValue: Number = 0;

  cart$: Observable<[]>;

  constructor(private service: AppService, private store: Store<{ cart: [] }>) {
    //this.info$ = store.select('info');
    this.cart$ = store.select('cart');
  }

  get_cart(){
    return this.cart$.pipe(map((data:any) => data));
  }

  // getKQ(){
  //   return this.info$.pipe(map((data:any) => data));
  // }

  // hello = 'Xin chào';

  // color = 'red';

  // color2 = 'red';

  // array = [1,2,3,4,5];

  // html = '<h1>Hello h1</h1>';

  array_product:any;
  array = [];

  ngOnInit(): void {
    this.service
    .list_product()
    .subscribe((kq:any)=>{
      this.array_product = kq['data'];
      //console.log(this.array_product);
    })
    // this.getKQ()
    // .subscribe((kq:any)=>{
    //   //this.array = kq;
    //   console.log(kq);
    // })

    // Lấy danh sách giỏ hàng
    this.get_cart()
    .subscribe((kq:any)=>{
      //console.log(kq)
    });
  }

  // change_color(){
  //   //this.color2 = 'black';
  // }

  // abc:any;

  // add(id:any, name:any, age:any){
  //   this.abc = this.store.dispatch(addInfo(new Info(parseInt(id.value), name.value, parseInt(age.value))))
  //   //this.currentValue = this.abc.length;
  //   // this.getKQ()
  //   // .subscribe((kq:any)=>{
  //   //   console.log(kq.info.length)
  //   // })
  // }

  // edit(id:any, name:any, age:any){
  //   this.store.dispatch(updateInfo(new Info(parseInt(id), name, parseInt(age))));
  // }

  // delete(id:any){
  //   this.store.dispatch(deleteInfo(id));
  // }

  add_to_cart(id:any, name:any, price:any, qty:any){
    this.store.dispatch(addCart(new Cart(id,name,parseInt(price),parseInt(qty))))
  }

}
