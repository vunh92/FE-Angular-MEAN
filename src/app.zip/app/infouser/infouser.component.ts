import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-infouser',
  templateUrl: './infouser.component.html',
  styleUrls: ['./infouser.component.css']
})
export class InfouserComponent implements OnInit {

  constructor() { }

  localst:any = 'No value';

  ngOnInit(): void {
    if(localStorage.getItem('key')){
      this.localst = localStorage.getItem('key');
    }
    
  }

}
