import { Component, OnInit } from '@angular/core';

// Gọi Service
import { AppService } from '../app.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private service: AppService) { }

  ngOnInit(): void {
  }

  get_data_Login(data:any)
  {
    // localstorage

    // 1. tạo
    //localStorage.setItem('key', 'hello localstorage');
    // 2. lấy sử dụng
    //localStorage.getItem('key');
    // 3. xóa
    //localStorage.removeItem("key");

    this.service
    .send_data_login(data)
    .subscribe((kq:any)=>{
      localStorage.setItem('key', kq['token']);
      //console.log(kq)
    })
  }

}
