import { Component, OnInit } from '@angular/core';

// Gọi ActivatedRoute, ParamMap
import { ActivatedRoute, ParamMap } from '@angular/router';

// Gọi Service
import { AppService } from '../app.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  constructor(private router: ActivatedRoute, private service: AppService) { }

  slug:any;
  name:any;
  price:any;

  related__products:any;

  ngOnInit(): void {
    this.router
    .paramMap
    .subscribe((params:ParamMap)=>{
      this.slug = params.get('id');

      // Lấy thông tin sản phẩm
      this.service
      .get_info_product(this.slug.split('.')[0])
      .subscribe((kq:any)=>{
        this.name = kq['data'][0].name;
        this.price = kq['data'][0].price;

        // Lấy ra sản phẩm liên quan
        this.service
        .related__products(kq['data'][0]._id, kq['data'][0].parent)
        .subscribe((kq2:any)=>{
          this.related__products = kq2['data'];
        })

      })
    });

    // this.service
    // .list_product()
    // .subscribe((kq)=>{
    //   console.log(kq);
    // })
  }

}
